package com.infy.dto;

public enum CourierStatus {
	BOOKED,DISPATCHED,IN_TRANSIT,DELIVERED;
}
