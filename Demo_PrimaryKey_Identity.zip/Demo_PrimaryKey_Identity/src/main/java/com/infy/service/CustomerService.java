package com.infy.service;

import com.infy.dto.CustomerDTO;

public interface CustomerService {
	public Integer addCustomer(CustomerDTO customerDTO);
}
