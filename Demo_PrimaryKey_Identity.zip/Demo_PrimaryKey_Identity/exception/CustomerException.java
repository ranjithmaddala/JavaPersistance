package com.infy.exception;

public class CustomerException {

}
