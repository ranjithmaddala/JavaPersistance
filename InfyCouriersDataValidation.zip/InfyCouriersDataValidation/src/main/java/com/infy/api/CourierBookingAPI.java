package com.infy.api;


import javax.validation.Valid;
import javax.validation.constraints.Max;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dto.BookingDTO;
import com.infy.exception.InfyCourierException;
import com.infy.service.BookingService;

@RestController
@RequestMapping(value="/infycourier")
@Validated
public class CourierBookingAPI {

	@Autowired
	private BookingService bookingService;
	
	@Autowired
	private Environment environment;

	@PostMapping(value="/courier")
	public ResponseEntity<String> bookCourier(@Valid @RequestBody BookingDTO bookingDTO) throws InfyCourierException {
		Integer id = bookingService.bookCourier(bookingDTO);
		String msg = environment.getProperty("API.BOOKING_SUCCESS") + id;
		return new ResponseEntity<>(msg,HttpStatus.CREATED);
	}

	@GetMapping(value="/courier/{bookingId}")
	public ResponseEntity<BookingDTO> getCourierDetails(@PathVariable Integer bookingId) throws InfyCourierException {	
		BookingDTO booking = bookingService.getCourierDetail(bookingId);
		return new ResponseEntity<>(booking, HttpStatus.OK);
	}
	
}