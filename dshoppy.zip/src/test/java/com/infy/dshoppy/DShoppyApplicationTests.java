package com.infy.dshoppy;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.dshoppy.dto.CostumeDTO;
import com.infy.dshoppy.dto.CustomerDTO;
import com.infy.dshoppy.entity.Costume;

import com.infy.dshoppy.exception.DShoppyException;
import com.infy.dshoppy.repository.CostumeRepository;
import com.infy.dshoppy.repository.CustomerRepository;
import com.infy.dshoppy.service.DShoppyService;
import com.infy.dshoppy.service.DShoppyServiceImpl;

@SpringBootTest
public class DShoppyApplicationTests {

	@Mock
	private CostumeRepository costumeRepository;
	
	@Mock
	private CustomerRepository customerRepository;
	
	@InjectMocks
	private DShoppyService dShoppyService = new DShoppyServiceImpl();
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Test
	public void getCustomersByCostumeSizeNoCustomerFoundTest(){
		//your code goes here
		String size="XL";
		
		Mockito.when(customerRepository.findByCostumeSize(Mockito.anyString())).thenReturn(List.of());
		DShoppyException e = Assertions.assertThrows(DShoppyException.class, ()->dShoppyService.getCustomersByCostumeSize(size));
		Assertions.assertEquals("Service.CUSTOMERS_UNAVAILABLE", e.getMessage());
	}
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Test
	public void purchaseCostumeStockUnavailableTest() {
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerName("Kate");
		customerDTO.setEmailId("kate@abc.com");
		customerDTO.setOccasionName("Trendy");
			
		CostumeDTO costumeDTO = new CostumeDTO();
		costumeDTO.setOccasion("Trendy");
		
		customerDTO.setCostumeDTO(costumeDTO);
		
		Costume costume= new Costume();
		costume.setStockAvailable(0);
		
		Mockito.when(costumeRepository.findByOccasion(customerDTO.getOccasionName())).thenReturn(costume);
		
		DShoppyException exception = Assertions.assertThrows(DShoppyException.class, ()->dShoppyService.purchaseCostume(customerDTO));
		Assertions.assertEquals("Service.STOCK_UNAVAILABLE",exception.getMessage());
	}
	
}



