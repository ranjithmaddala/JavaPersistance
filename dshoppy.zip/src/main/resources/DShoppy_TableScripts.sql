DROP SCHEMA IF EXISTS d_shoppy_db;

CREATE SCHEMA d_shoppy_db;
USE d_shoppy_db;

CREATE TABLE costume (
	costume_id INT PRIMARY KEY,
	occasion VARCHAR(50) NOT NULL,
	size VARCHAR(50) NOT NULL,
	stock_available INT NOT NULL
);

CREATE TABLE customer (
	customer_id INT AUTO_INCREMENT,
	name VARCHAR(50) NOT NULL,
	email_id VARCHAR(100) NOT NULL,
	occasion_name VARCHAR(100) NOT NULL,
	costume_id INT,
	CONSTRAINT ps_customer_id_pk PRIMARY KEY (customer_id),
	CONSTRAINT fs_costume_id_fk FOREIGN KEY (costume_id) REFERENCES costume(costume_id)
);

INSERT INTO costume(costume_id, occasion, size, stock_available) VALUES (1011, 'Festive', 'S', 3);
INSERT INTO costume(costume_id, occasion, size, stock_available) VALUES (1012, 'Casual', 'M', 15);
INSERT INTO costume(costume_id, occasion, size, stock_available) VALUES (1013, 'Lounge', 'L', 5);
INSERT INTO costume(costume_id, occasion, size, stock_available) VALUES (1014, 'Formal', 'L', 6);

INSERT INTO customer(customer_id, name, email_id, occasion_name, costume_id) VALUES (1001, 'Jake', 'jake@abc.com', 'Festive', 1011);
INSERT INTO customer(customer_id, name, email_id, occasion_name, costume_id) VALUES (1002, 'Mary', 'mary@abc.com', 'Formal', 1014);
INSERT INTO customer(customer_id, name, email_id, occasion_name, costume_id) VALUES (1003, 'Kenny', 'kenny@abc.com', 'Lounge', 1013);
INSERT INTO customer(customer_id, name, email_id, occasion_name, costume_id) VALUES (1004, 'Brad', 'brad@abc.com', 'Formal', 1014);
INSERT INTO customer(customer_id, name, email_id, occasion_name, costume_id) VALUES (1005, 'Alice', 'alice@abc.com', 'Casual', 1012);
INSERT INTO customer(customer_id, name, email_id, occasion_name, costume_id) VALUES (1006, 'Smith', 'smith@abc.com', 'Casual', 1012);
INSERT INTO customer(customer_id, name, email_id, occasion_name, costume_id) VALUES (1007, 'John', 'john@abc.com', 'Lounge', 1013);


select*from costume;
select*from customer;