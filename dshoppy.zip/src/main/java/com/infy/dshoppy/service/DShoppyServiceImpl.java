package com.infy.dshoppy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dshoppy.dto.CostumeDTO;
import com.infy.dshoppy.dto.CustomerDTO;
import com.infy.dshoppy.entity.Costume;
import com.infy.dshoppy.entity.Customer;
import com.infy.dshoppy.exception.DShoppyException;
import com.infy.dshoppy.repository.CostumeRepository;
import com.infy.dshoppy.repository.CustomerRepository;

@Service(value="dShoppyService")
@Transactional
public class DShoppyServiceImpl implements DShoppyService {

	@Autowired
	private CostumeRepository costumeRepository;

	@Autowired
	private CustomerRepository customerRepository;
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Override
	public Integer purchaseCostume(CustomerDTO customerDTO) throws DShoppyException {
		// TODO Auto-generated method stub
		Costume costume = costumeRepository.findByOccasion(customerDTO.getCostumeDTO().getOccasion());
					
		if(costume.getStockAvailable()==0) {
			throw new DShoppyException("Service.STOCK_UNAVAILABLE");
		}
		
		List<Customer> c =customerRepository.findByEmailId(customerDTO.getEmailId());
		if(!c.isEmpty()){
			for(Customer c1 : c) {
				if(c1.getOccasionName().equals(customerDTO.getOccasionName())) {
					throw new DShoppyException("Service.CUSTOMER_PURCHASED_COSTUME");
				}
			}
		}
				
		Customer customer = new Customer();
		customer.setCustomerName(customerDTO.getCustomerName());
		customer.setEmailId(customerDTO.getEmailId());
		customer.setOccasionName(customerDTO.getOccasionName());
		customer.setCostume(costume);
		
		costume.setStockAvailable(costume.getStockAvailable()-1);
		
		customerRepository.save(customer);
		return customer.getCustomerId();
	}
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Override
	public List<CustomerDTO> getCustomersByCostumeSize(String size) throws DShoppyException {
		//your code goes here
		List<Customer> customerList = customerRepository.findByCostumeSize(size);
		if(customerList.isEmpty()) {
    		throw new DShoppyException("Service.CUSTOMERS_UNAVAILABLE");
    	}
		List<CustomerDTO> customersNewList=new ArrayList<>();
		for(Customer customer:customerList) {
			CustomerDTO customerDTO = new CustomerDTO();
			CostumeDTO costumeDTO = new CostumeDTO();
			Costume costume=customer.getCostume();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setCustomerName(customer.getCustomerName());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setOccasionName(customer.getOccasionName());
			customerDTO.setCostumeDTO(costumeDTO);
			costumeDTO.setCostumeId(costume.getCostumeId());
			costumeDTO.setOccasion(costume.getOccasion());
			costumeDTO.setSize(size);
			costumeDTO.setStockAvailable(costume.getStockAvailable());
			customersNewList.add(customerDTO);
		}
		return customersNewList;	
	}
}

