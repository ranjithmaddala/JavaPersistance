package com.infy.dshoppy.service;

import java.util.List;

import com.infy.dshoppy.dto.CustomerDTO;
import com.infy.dshoppy.exception.DShoppyException;


public interface DShoppyService {
	Integer purchaseCostume(CustomerDTO customerDTO) throws DShoppyException;
	List<CustomerDTO> getCustomersByCostumeSize(String size) throws DShoppyException;
}
