package com.infy.dshoppy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="costume")
public class Costume {
	@Id
	private Integer costumeId;
	private String occasion;
	private String size;
	private Integer stockAvailable;
	
	public Integer getCostumeId() {
		return costumeId;
	}
	public void setCostumeId(Integer costumeId) {
		this.costumeId = costumeId;
	}
	public String getOccasion() {
		return occasion;
	}
	public void setOccasion(String occasion) {
		this.occasion = occasion;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public Integer getStockAvailable() {
		return stockAvailable;
	}
	public void setStockAvailable(Integer stockAvailable) {
		this.stockAvailable = stockAvailable;
	}
}
