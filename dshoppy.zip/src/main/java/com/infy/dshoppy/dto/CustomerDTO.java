package com.infy.dshoppy.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class CustomerDTO {

	private Integer customerId;
	
	@NotNull(message="{customer.name.notpresent}")
	@Pattern(regexp = "([A-Z][a-z]+)( [A-Z][a-z]+)*", message = "{customer.name.invalid}")
	private String customerName;
	
	@NotNull(message = "{customer.emailid.notpresent}")
	@Email(message = "{customer.emailid.invalid}")
	private String emailId;

	@NotNull(message="{customer.occasionName.notpresent}")
	@Pattern(regexp = "(Festive|Lounge|Casual|Formal)", message ="{customer.occasionName.invalid}")
	private String occasionName;
	
	@NotNull(message="{customer.costume.notpresent}")
	private CostumeDTO costumeDTO;

	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getOccasionName() {
		return occasionName;
	}
	public void setOccasionName(String occasionName) {
		this.occasionName = occasionName;
	}
	public CostumeDTO getCostumeDTO() {
		return costumeDTO;
	}
	public void setCostumeDTO(CostumeDTO costumeDTO) {
		this.costumeDTO = costumeDTO;
	}
}
