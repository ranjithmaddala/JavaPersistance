package com.infy.dshoppy.api;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dshoppy.dto.CustomerDTO;
import com.infy.dshoppy.exception.DShoppyException;
import com.infy.dshoppy.service.DShoppyService;

@RestController
@Validated
@RequestMapping(value="/dshoppy-api")

public class DShoppyAPI {

	@Autowired
	private DShoppyService dShoppyService;
	
	@Autowired
	private Environment environment;
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@PostMapping("/purchaseCostume")
	public ResponseEntity<String> purchaseCostume(@Valid @RequestBody CustomerDTO customerDTO)
			throws DShoppyException {
		return new ResponseEntity<>(environment.getProperty("API.REGISTRATION_SUCCESS")+" : "+dShoppyService.purchaseCostume(customerDTO), HttpStatus.CREATED);
	}

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@GetMapping("/costume/{size}")
	public ResponseEntity<List<CustomerDTO>> getCustomersByCostumeSize(@Pattern(regexp = "(S|M|L)", message = "{costume.size.invalid}") String size)
			throws DShoppyException {
		
		List<CustomerDTO> customerList= dShoppyService.getCustomersByCostumeSize(size);
		return new ResponseEntity<List<CustomerDTO>>(customerList,HttpStatus.OK);
	}

	
}
