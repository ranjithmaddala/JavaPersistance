package com.infy.dshoppy.repository;


import org.springframework.data.repository.CrudRepository;

import com.infy.dshoppy.entity.Costume;

public interface CostumeRepository extends CrudRepository<Costume, Integer>{
	
	Costume findByOccasion(String occasion);
}
