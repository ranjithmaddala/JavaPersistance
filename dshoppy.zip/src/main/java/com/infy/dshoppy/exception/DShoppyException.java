package com.infy.dshoppy.exception;

public class DShoppyException extends Exception {

	private static final long serialVersionUID = 1L;

	public DShoppyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
