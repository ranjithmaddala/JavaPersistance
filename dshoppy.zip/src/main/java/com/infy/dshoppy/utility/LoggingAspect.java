package com.infy.dshoppy.utility;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.infy.dshoppy.exception.DShoppyException;

@Aspect
@Component
public class LoggingAspect {
	
	private static final Log LOGGER = LogFactory.getLog(LoggingAspect.class);
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@AfterThrowing(pointcut = "execution(* com.infy.dshoppy.service.DShoppyServiceImpl.*(..))" , throwing="exception")
	public void logServiceException(DShoppyException exception) {
		LOGGER.error(exception.getMessage(), exception);
	}

}
