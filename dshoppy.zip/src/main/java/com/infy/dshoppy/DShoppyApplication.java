package com.infy.dshoppy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.infy.dshoppy.exception.DShoppyException;


@SpringBootApplication
public class DShoppyApplication{

	public static void main(String[] args) throws DShoppyException{
			
		SpringApplication.run(DShoppyApplication.class, args);
	}
}