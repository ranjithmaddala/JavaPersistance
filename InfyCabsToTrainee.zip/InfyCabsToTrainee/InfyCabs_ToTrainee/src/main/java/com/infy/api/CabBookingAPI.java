package com.infy.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dto.CabBookingDTO;
import com.infy.exception.InfyCabException;
import com.infy.service.BookingService;


@RestController
@RequestMapping(value="/booking")
public class CabBookingAPI {
	
	@Autowired
	private BookingService bookingService;
	
	@Autowired
	private Environment environment;
	
	@PostMapping(value="/")
	public ResponseEntity<String> bookCab(@RequestBody CabBookingDTO cabBookingDTO) throws InfyCabException {
		Integer id = bookingService.bookCab(cabBookingDTO);
		String successMessage = environment.getProperty("API.BOOKING_SUCCESSFUL") + id;
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}

	@GetMapping(value="/{mobileNo}")
	public ResponseEntity<List<CabBookingDTO>> getBookingDetails(@PathVariable Long mobileNo) throws InfyCabException {
		List<CabBookingDTO> bookingList = bookingService.getBookingDetails(mobileNo);
		
		return  new ResponseEntity<>(bookingList, HttpStatus.OK);
	}
	
	@PutMapping(value="/{bookingId}")
	public ResponseEntity<String> cancelBooking(@PathVariable Integer bookingId) throws InfyCabException {
		Integer cancelId = bookingService.cancelBooking(bookingId);
		String successMessage = environment.getProperty("API.BOOKING_CANCELLED");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

}
